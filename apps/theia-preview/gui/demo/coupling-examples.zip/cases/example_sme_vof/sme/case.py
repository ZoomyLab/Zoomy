# %% [markdown] zoomy={"role":"meta","title":"sme (SME participant)","description":"Coupled SME arm."}
# # sme (SME participant)
#
# Coupled SME arm.

# %% [markdown] zoomy={"role":"heading","section":"model"}
# ## Model

# %% zoomy={"role":"model","class_path":"zoomy_core.model.models.SME","init":{"level":2}}
from zoomy_core.model.models import SME
from zoomy_core.model.boundary_conditions import BoundaryConditions, Coupled, FromModel
# Coupled SME participant: wall on the outer boundary, a preCICE Coupled BC on the
# shared interface (mesh_name matches the exchange mesh "SweMesh" in ../precice-config.xml).
model = SME(level=2, boundary_conditions=BoundaryConditions([
    FromModel(tag="outer", definition="wall"),
    Coupled(tag="coupled", mesh_name="SweMesh")]))

# %% [markdown] zoomy={"role":"heading","section":"mesh"}
# ## Mesh

# %% zoomy={"role":"mesh","spec":{"x_min":0,"x_max":10,"n_cells":40}}


# %% [markdown] zoomy={"role":"heading","section":"settings"}
# ## Solver settings

# %% zoomy={"role":"settings","settings":{"backend": "foam", "solver_id": "solver-foam"}}
settings = {
  "backend": "foam",
  "solver_id": "solver-foam"
}

# %% [markdown] zoomy={"role":"heading","section":"run"}
# ## Run

# %% zoomy={"role":"run"}
# COUPLED PARTICIPANT — do not run standalone. Launch the whole coupling from the
# parent folder's "Run coupled" (foam backend + preCICE): every participant is
# started together, shares the coupling folder (the preCICE exchange-directory)
# and they find each other over sockets. In the GUI, running this case alone is
# gated on a connected "foam" backend (the selected solver is zoomyFoam, not
# numpy) — it is NOT a local numpy run.
