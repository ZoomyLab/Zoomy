# %% [markdown] zoomy={"role":"meta","title":"vof (VOF confluence)","description":"Coupled VOF, two interfaces."}
# # vof (VOF confluence)
#
# Coupled VOF, two interfaces.

# %% [markdown] zoomy={"role":"heading","section":"model"}
# ## Model

# %% zoomy={"role":"model","class_path":null,"init":{}}
from zoomy_core.model.boundary_conditions import BoundaryConditions, Coupled
# Incompressible Volume-of-Fluid participant (interFoam / incompressibleVoF).
# Coupled to its SME neighbour(s) over preCICE on 2 interface mesh(es);
# the VOF field + mesh are configured on the foam backend (this case marks the coupling).
coupled_interfaces = BoundaryConditions([
    Coupled(tag="coupled_0", mesh_name="Mesh1"),
    Coupled(tag="coupled_1", mesh_name="Mesh1")])

# %% [markdown] zoomy={"role":"heading","section":"mesh"}
# ## Mesh

# %% zoomy={"role":"mesh","spec":{"x_min":0,"x_max":10,"n_cells":40}}


# %% [markdown] zoomy={"role":"heading","section":"settings"}
# ## Solver settings

# %% zoomy={"role":"settings","settings":{"backend": "OpenFOAM", "solver_id": "solver-foam-vof"}}
settings = {
  "backend": "OpenFOAM",
  "solver_id": "solver-foam-vof"
}

# %% [markdown] zoomy={"role":"heading","section":"run"}
# ## Run

# %% zoomy={"role":"run"}
# COUPLED PARTICIPANT — do not run standalone. Launch the whole coupling from the
# parent folder's "Run coupled" (foam backend + preCICE): every participant is
# started together, shares the coupling folder (the preCICE exchange-directory)
# and they find each other over sockets. In the GUI, running this case alone is
# gated on a connected "foam" backend (the selected solver is zoomyFoam, not
# numpy) — it is NOT a local numpy run.
